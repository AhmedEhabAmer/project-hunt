Free for non commercial use. Be sure to check out the Polygon Academy YouTube Channel for more tutorials and game industry content! http://www.youtube.com/c/PolygonAcademy
No art/level scenes are included in this pack, just the presets.

Link to the how to use tutorial: https://youtu.be/_bqpw5sOwr4